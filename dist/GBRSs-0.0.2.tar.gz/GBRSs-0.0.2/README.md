# GBRS
The curerent complete versions of GBRS
The original group-based PP POI RS. This is actually the second version of the code.
In order to use this current version. Just run the only python file. In the future I will try to change it to a library, but for now, things are very primative.
Also, make sure your path is correct.
Contract me if you encounter any bugs or just raise an issue so I get notified. 

Current version has three projects:

Behnaze's 
Original
Wali's

They are very similar with key differences. So work on the one that you want, and since the stem of the codes are very similar, if you think you have done somthing nice to reduce the complexity or it made the code more concise, please let the other team members know.

Thanks
LC
